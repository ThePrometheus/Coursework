This directory contains Python brotli wrapper module and roundtrip tests.

To build module execute `python setup.py build_ext` from root project directory.

To test module run `python setup.py test`.
